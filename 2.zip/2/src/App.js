import React from 'react';
import './App.css';
import Register from './components/Register';

import Submit from './components/Submit';
function App() {
  return (
 
   <div className='G1'>
    <Register/>
   </div>

  );
}

export default App;